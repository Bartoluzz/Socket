
package socekthread;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server extends Thread{
    
    public final static int porta = 8080;
    ServerSocket server = null;
    
    
    
    public void connection(){
        
        ServerSocket server = null;
        
        try{
            server = new ServerSocket (porta);
            System.out.println("[1] - Server in ascolto... ");
            server.setReuseAddress(true);
            
            while(true){
                
                Socket client = server.accept();
                System.out.println("[2] - Connessione accettata dal client " + client.getInetAddress().getHostName());
                
                GestoreClients clientsock = new GestoreClients(client); //creare la classe GestoreSocket
                new Thread(clientsock).start();
            }
            
        }catch(IOException err){
            err.printStackTrace();
        }
        
        finally{
            if(server != null){
                try{
                    server.close();
                }catch(IOException err){
                    err.printStackTrace();
                }
            }
        }

    }
    
    public static void main(String[] args) {
        
        Server s = new Server();
        s.connection();
        
        
    }
    
    
    private static class GestoreClients extends Thread {
        private Socket clientSocket;
  
        public GestoreClients(Socket socket){
            this.clientSocket = socket;
        }
  
        public void run()
        {
            PrintWriter out = null;
            BufferedReader in = null;
            try {
                 
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
  
                String line;
                while ((line = in.readLine()) != null) {
                    System.out.printf(" Messaggio inviato dal client: %s\n",line);
                    out.println(line);
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            
            finally {
                try {
                    if (out != null) 
                        out.close();
                  
                    if (in != null) {
                        in.close();
                        clientSocket.close();
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    
}


